<footer class="main-footer d-flex p-2 px-3 bg-white border-top">
            <span class="copyright ml-auto my-auto mr-2">Copyright © <?=date('Y');?>
              <a href="https://designrevision.com" rel="nofollow">Simple Web Cart</a>
            </span>          
        </footer>